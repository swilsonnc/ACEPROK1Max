import{S as r}from"./Viewer-C8kn4zwf.js";const e="kernelBlurVaryingDeclaration",a="varying sampleCoord{X}: vec2f;";r.IncludesShadersStoreWGSL[e]=a;
