import{S as r}from"./Viewer-BscFYDD2.js";const e="kernelBlurVaryingDeclaration",a="varying vec2 sampleCoord{X};";r.IncludesShadersStore[e]=a;
